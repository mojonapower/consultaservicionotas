
function consultaNota()
{

	var correo=document.getElementById('correo').value;

	if(correo=='')
	{
		alert('Debe Ingresar los valores!');
	}
	else
	{
		$.ajax({
		cache: false,
		// puede ser GET, POST
		type: "POST",  							
		// Tipo de retorno
		dataType: "html",
		// pagina php que recibe la llamada
		url: "http://72.14.183.67:8282/consultaNotas",
		// datos, ej: $_POST['data']
		data: {
			correo:correo,
			respMat:2
		},
		beforeSend: function(){  
                    alert("enviando")	
		},
		// acciones cuando me retorna algo el PHP
		success: function( msg){
			//console.log(msg);
			console.log($("#labelResultado").html('Respuesta WS: '+msg));
			alert(msg)
		},							
		// acciones cuando hay error en comunicacion el el php
		error: function(xhr, status,msg2 ){
			//alert('4');			
			console.log(xhr);
		}
	});//fin ajax
	}//fin else
}

